import { useState } from "react";
import { PAGES } from "../config.js";
import { friendlyError } from "../errors.js";
import { hasUploadLeft } from "../api.js";
import { domainList } from "../validation.js";
import { useAuthSession } from "../shared/useAuthSession.js";
import Header from "../shared/Header.jsx";
import UploadForm from "./UploadForm.jsx";
import RequestPanel from "./RequestPanel.jsx";

export default function UploadPage() {
  const session = useAuthSession();
  const [lastUpload, setLastUpload] = useState(null);
  const { status, user, userDoc, notice } = session;

  async function onDone(result) {
    setLastUpload(result);
    await session.reloadUserDoc();
    window.scrollTo({ top: 0 });
  }

  let body;
  if (status === "loading" || status === "seating") {
    body = <p className="hint" aria-live="polite">{status === "seating" ? "Finding you a seat…" : "Checking your session…"}</p>;
  } else if (status === "ready") {
    body = (
      <>
        <dl className="quota">
          <div><dt>Account</dt><dd>{user.email}</dd></div>
          <div><dt>Uploads used</dt><dd>{userDoc.uploadsUsed} of {userDoc.uploadsAllowed}</dd></div>
        </dl>
        {hasUploadLeft(userDoc)
          ? <UploadForm user={user} onDone={onDone} />
          : <RequestPanel user={user} lastUpload={lastUpload} onCheck={session.reloadUserDoc} />}
      </>
    );
  } else if (status === "error") {
    body = <p className="status is-error">{friendlyError(session.error)}</p>;
  } else {
    // signed out, or email not verified yet
    body = (
      <div className="panel">
        {notice?.type === "full" && <div className="notice" role="alert"><strong>All seats are in use</strong>Only 80 people can be signed in at once. Try again in a few minutes.</div>}
        {notice?.type === "lost" && <div className="notice" role="alert"><strong>You were signed out</strong>Your seat was taken while you were away. Try signing in again.</div>}
        {notice?.type === "domain" && <div className="notice" role="alert"><strong>That email can't be used</strong>Only {domainList()} emails are allowed.</div>}
        <h2 className="section-title">{status === "unverified" ? "Verify your email first" : "Sign in to upload"}</h2>
        <p className="lede" style={{ marginTop: 12 }}>
          {status === "unverified"
            ? "Your email isn't verified yet. Finish verification, then come back here."
            : `Uploading needs an account with a ${domainList()} email. You can browse projects without one.`}
        </p>
        <div className="btn-row" style={{ marginTop: 0 }}>
          <a className="btn btn-primary" href={PAGES.auth}>{status === "unverified" ? "Verify email" : "Sign in or create account"}</a>
        </div>
      </div>
    );
  }

  return (
    <>
      <Header email={status === "ready" ? user.email : null} onLogout={status === "ready" ? session.logout : undefined} />
      <main className="page">
        <div className="wrap upload-wrap">
          <h1 className="page-title">Upload a project</h1>
          {status === "ready" && hasUploadLeft(userDoc) && (
            <p className="lede">Add a cover, your team and your work. Each email can upload once.</p>
          )}
          {body}
        </div>
      </main>
    </>
  );
}

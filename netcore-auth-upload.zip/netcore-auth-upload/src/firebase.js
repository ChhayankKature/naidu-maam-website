// Firebase setup. The config is the one from your Firebase console.
// (Firebase web config values are identifiers, not secrets. Access is
// controlled by firestore.rules and storage.rules, not by hiding this.)
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAnalytics, isSupported } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyCeyPt81h0TarBOeCQPwFEQ_xKhEDlXO",
  authDomain: "cn-mam-website.firebaseapp.com",
  projectId: "cn-mam-website",
  storageBucket: "cn-mam-website.firebasestorage.app",
  messagingSenderId: "462565559824",
  appId: "1:462565559824:web:73860122a0aae89bd20495",
  measurementId: "G-5ZEBPGG5Z3"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Analytics only works in some browsers; never let it break the page.
isSupported().then((ok) => { if (ok) getAnalytics(app); }).catch(() => {});

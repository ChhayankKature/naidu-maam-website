// One hook for both pages. It answers: who is signed in, are they allowed,
// and do they hold one of the 80 seats?
//
// status:
//   loading     waiting for Firebase
//   signedOut   nobody signed in
//   unverified  signed in, but the email isn't verified yet
//   seating     verified, getting a seat
//   ready       verified and seated: can upload
//   error       something failed (see `error`)
// notice: why someone was just signed out ("full" | "lost" | "domain")
import { useCallback, useEffect, useRef, useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "../firebase.js";
import { emailProblem } from "../validation.js";
import { claimSeat, startHeartbeat } from "../session.js";
import { ensureUserDoc, getUserDoc } from "../api.js";

export function useAuthSession() {
  const [state, setState] = useState({ status: "loading", user: null, userDoc: null, error: null });
  const [notice, setNotice] = useState(null);
  const beat = useRef(null);
  const run = useRef(0);

  const stopBeat = () => { beat.current?.stop(); beat.current = null; };

  const evaluate = useCallback(async (user) => {
    const id = ++run.current;
    stopBeat();

    if (!user) { setState({ status: "signedOut", user: null, userDoc: null, error: null }); return; }

    // Rule 1, second line of defence: accounts made outside this page can't get in either.
    if (emailProblem(user.email || "")) {
      setNotice({ type: "domain", email: user.email });
      await signOut(auth);
      return;
    }
    if (!user.emailVerified) { setState({ status: "unverified", user, userDoc: null, error: null }); return; }

    setState({ status: "seating", user, userDoc: null, error: null });
    try {
      const seat = await claimSeat(user.uid);
      if (id !== run.current) return;
      if (seat === null) { setNotice({ type: "full" }); await signOut(auth); return; }

      const userDoc = await ensureUserDoc(user);
      if (id !== run.current) return;

      beat.current = startHeartbeat({
        uid: user.uid,
        seat,
        onLost: async () => { setNotice({ type: "lost" }); await signOut(auth); }
      });
      setState({ status: "ready", user, userDoc, error: null });
    } catch (error) {
      console.error(error);
      if (id === run.current) setState({ status: "error", user, userDoc: null, error });
    }
  }, []);

  useEffect(() => {
    const off = onAuthStateChanged(auth, evaluate);
    return () => { off(); stopBeat(); };
  }, [evaluate]);

  /** After the person clicks the link in the verification email. */
  const recheckVerification = useCallback(async () => {
    if (!auth.currentUser) return;
    await auth.currentUser.reload();
    // The security rules read "email verified" from the login token, which still says
    // "not verified" until it's refreshed. Without this the rules reject them for up to an hour.
    if (auth.currentUser.emailVerified) await auth.currentUser.getIdToken(true);
    await evaluate(auth.currentUser);
  }, [evaluate]);

  const reloadUserDoc = useCallback(async () => {
    const uid = auth.currentUser?.uid;
    if (!uid) return null;
    const userDoc = await getUserDoc(uid);
    setState((s) => ({ ...s, userDoc }));
    return userDoc;
  }, []);

  const logout = useCallback(async () => {
    const b = beat.current;
    beat.current = null;
    if (b) await b.release(); // frees the seat straight away
    await signOut(auth);
  }, []);

  return { ...state, notice, clearNotice: () => setNotice(null), recheckVerification, reloadUserDoc, logout };
}

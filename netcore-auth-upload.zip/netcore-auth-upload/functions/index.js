// OPTIONAL. Stops accounts for other emails from being created at all.
//
// Without this, anyone can technically create a Firebase account with any email
// (Firebase has no allow-list setting). That account is useless: every rule in
// firestore.rules / storage.rules rejects it, and the sign-in page signs it out.
// This function just closes the door earlier, so no stray accounts pile up.
//
// Needs: the Blaze plan + "Upgrade to Identity Platform" in Authentication > Settings.
// To use it, add this to firebase.json and run `firebase deploy --only functions`:
//   "functions": [{ "source": "functions", "codebase": "default" }]
const { beforeUserCreated, beforeUserSignedIn, HttpsError } = require("firebase-functions/v2/identity");

const ALLOWED = /^[^+@\s]+@(rbunagpur\.in|rknec\.edu)$/;

function check(event) {
  const email = (event.data.email || "").toLowerCase();
  if (!ALLOWED.test(email)) {
    throw new HttpsError("invalid-argument", "Only @rbunagpur.in and @rknec.edu emails are allowed.");
  }
}

exports.onlyCollegeEmailsCreate = beforeUserCreated(check);
exports.onlyCollegeEmailsSignIn = beforeUserSignedIn(check);

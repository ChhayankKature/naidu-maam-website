# NetCore: sign-in and upload pages

Two new pages and a Firebase backend. **Not merged into the main site yet.** This is a separate project in the same stack (Vite + React), with the same colors, fonts and light/dark switch.

- `auth.html`: sign in / create account / reset password. Shows the 80 seats live.
- `upload.html`: the upload form. Guests see a "sign in" prompt instead.
- `firestore.rules`, `storage.rules`: **the real enforcement of your rules.** Read these first.
- `functions/`: optional extra lock on account creation (see "Optional" below).

## Run it

1. `npm install`
2. `npm run dev`, then open `/auth.html` and `/upload.html`.
3. `npm test` runs the form checks (email domains, title, file types, 5 MB, links, team).
4. `npm run build` builds both pages into `dist/`.

## One-time Firebase setup (project `cn-mam-website`)

1. **Authentication → Sign-in method:** switch on **Email/Password**. Under Settings → Authorized domains, add the domain the site will live on (`localhost` is there already).
2. **Firestore Database:** create a database (production mode).
3. **Storage:** click Get started. Projects created since late 2024 need the **Blaze (pay-as-you-go) plan** for Storage. It has a free monthly allowance.
4. **Deploy the rules** (this is what makes the rules binding):
   ```
   npm i -g firebase-tools
   firebase login
   firebase deploy --only firestore:rules,storage
   ```
   The CLI may ask permission to let Storage rules read Firestore. Say yes; rule 2 needs it.
5. **Make yourself an admin (for the later panel):** in Firestore, add a document `admins/<your uid>` (any field, e.g. `{ ok: true }`). Your uid is in Authentication → Users.

> **Check `src/firebase.js` first.** The `apiKey` you sent is 37 characters; Firebase keys are normally 39, so it may have been cut off when copied. If sign-in says the key is invalid, copy it again from Project settings → Your apps.

## Your five rules, and where each one is enforced

| # | Rule | How |
|---|------|-----|
| 1 | Only `@rbunagpur.in` / `@rknec.edu` | The page checks first. Every database and storage rule requires a **verified** email on those domains, so any other account can't read or write anything. `name+tag@…` aliases are refused (they would give one person several "emails"). |
| 2 | One upload per email | `users/{uid}` holds `uploadsAllowed` (starts at 1) and `uploadsUsed`. People can only raise `uploadsUsed` by exactly 1, in the same batch as their submission, never above `uploadsAllowed`. They can't edit or delete a submission. Only admins change `uploadsAllowed`. File uploads are also refused once the allowance is used. |
| 3 | One "upload another" request at a time | `requests/{uid}` holds the latest request. A person can create it, or set it back to `pending` only if it was `accepted` or `denied`, and only when their uploads are used up. Only admins can accept or deny. |
| 4 | 80 people signed in at once | 80 numbered seats, `slots/0` to `slots/79`. See "How the 80 limit works". |
| 5 | 5 MB max | `storage.rules` rejects any file over 5 MB (cover image and project file are each limited), and any type the form doesn't offer. |

## How the 80 limit works

Firebase can't count "people online", so each signed-in person holds one of 80 seats:

- After sign-in, the page claims a free seat and checks in every 2 minutes.
- A seat with no check-in for 5 minutes is free again. Closing a tab frees the seat within about 5 minutes; **Sign out** frees it at once.
- The rules only allow seats 0–79, never let someone take a seat that checked in recently, and **require a live seat to upload**.
- If all 80 are taken, the person is signed out with a "try again in a few minutes" message.
- Guests browsing don't use a seat.

**Limits of this approach:**
- Firebase can't refuse the sign-in itself, so a 81st person *can* log in at the Firebase level. They then have no seat, can't upload, and the page signs them out. If you need the login itself refused, that needs a Cloud Function.
- If you change `MAX_SEATS` or `LEASE_MS` in `src/config.js`, change the matching numbers in `firestore.rules` (`[1-7][0-9]` and `duration.value(5, 'm')`).
- Heartbeats cost about 30 database writes per signed-in person per hour. At 80 people that's roughly 2,400 writes an hour, well inside the free daily allowance for normal use.

## Data

| Path | Who can read | Contents |
|------|--------------|----------|
| `submissions/{uid}_{n}` | everyone | title, category, team **names**, cover and file URLs or link, `createdAt` |
| `submissionContacts/{uid}_{n}` | owner + admins | uploader email, team names **and emails** |
| `users/{uid}` | owner + admins | `email`, `uploadsAllowed`, `uploadsUsed` |
| `requests/{uid}` | owner + admins | `status` (`pending` / `accepted` / `denied`), `reason`, `createdAt` |
| `slots/*`, `sessions/*` | seats public, sessions private | seat bookkeeping, no emails |
| `admins/{uid}` | that person | marks an admin (created by hand) |
| Storage `submissions/{uid}/{n}/cover.webp` and `project.{ext}` | everyone | the files |

Emails are kept out of the public `submissions` documents on purpose, so the gallery can't be scraped for them.

## For the admin panel you're building later

- **Accept a request:** in one batch, set `requests/{uid}.status = "accepted"` and `users/{uid}.uploadsAllowed += 1`. Accepting only sets the status; the +1 is what actually lets them upload. (Their page shows the form again after "Check again" or a refresh.)
- **Deny:** set `requests/{uid}.status = "denied"`. They can send a new request straight away.
- **Remove a project:** delete `submissions/{id}`, `submissionContacts/{id}` and the files under `submissions/{uid}/{n}/`. This does *not* give the person their upload back; raise `uploadsAllowed` if you want that.
- Everything above works from the client because the rules treat `admins/{uid}` users as admins. Nobody can add themselves there.

## Choices I made where your brief was open (all easy to change)

- **Title:** letters only, so **no spaces** (`MyProject`, not `My Project`). To allow spaces, change `/^[A-Za-z]+$/` in `src/validation.js` and `'[A-Za-z]{1,25}'` in `firestore.rules`.
- **Team:** 1 to 6 members, each with a name and an email. The uploader's email is pre-filled in the first row. Team emails must also be college emails (`TEAM_EMAILS_MUST_MATCH_DOMAINS` in `src/config.js`).
- **5 MB** applies to the cover image and the project file separately.
- **Presentation:** `.pptx`, `.ppt`, `.odp` or `.pdf`. **Tools study / IPR / Story:** `.doc`, `.docx` or `.pdf`. **Certification:** `.pdf`. **Game:** https link only. **Projects:** your note said "link pdf", so the person picks a link **or** a PDF.
- **Sign-up needs a verified email.** After creating an account, they click the link Firebase emails them. Without this, anyone could claim an address they don't own.
- **Uploading is final.** The form asks for confirmation first, since the one upload is used.
- Hard cap of 20 uploads per person ever (the `nextN` list in the rules).

## Honest limits

- The rules were written carefully but **not run against the Firebase emulator** (it can't be downloaded in my build environment). After deploying, spend ten minutes on this checklist:
  1. Sign up with a gmail address → refused. With `name+1@rknec.edu` → refused.
  2. Sign up with a real college address, verify, sign in, upload once → works.
  3. Open the upload page again → shows "You've used your upload" and the request box.
  4. Send a request → button disappears while pending. In the console, set it to `accepted` and `uploadsAllowed` to 2 → form returns.
  5. In the browser console, try writing a second submission directly → refused.
  6. Open `/auth.html` in 2 browsers → the seat grid shows 2.
- "Cover must be WebP" is checked in the browser (including the file's first bytes) and the storage rule checks the declared content type. Storage can't inspect file contents, so someone who bypasses the page could mislabel a file.
- Team member names and emails can't be validated one by one in security rules (rules have no loops). The page checks them; the rules check the count (1–6).

## Optional: block other emails from creating accounts at all

Without it, someone can still create a Firebase account with any email. It can't do anything (every rule refuses it, and the page signs it out), but the account exists. `functions/index.js` blocks creation outright. It needs the Blaze plan and **Authentication → Settings → Upgrade to Identity Platform**. Add `"functions": [{ "source": "functions", "codebase": "default" }]` to `firebase.json`, then `cd functions && npm install && cd .. && firebase deploy --only functions`. Untested.

## Merging into the main site later

1. Copy `src/auth`, `src/upload`, `src/shared` and the files `src/firebase.js`, `src/config.js`, `src/validation.js`, `src/errors.js`, `src/session.js`, `src/api.js`. Also copy `auth.html` and `upload.html`.
2. Add `firebase` to the main `package.json`, and add `"auth.html", "upload.html"` to `build.rollupOptions.input` in `vite.config.js`.
3. In `src/config.js`, set `BRAND` and `NAV` to match the landing page. `src/shared/ui.css` uses the same tokens and class names as `landing.css`, and the same `nc-theme` storage key, so the theme choice carries over.
4. Turn the "Upload" link on the Projects page into a link to `upload.html`.

import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
// Same bundled fonts as the landing page, so both pages match.
import "@fontsource/michroma/400.css";
import "@fontsource/ibm-plex-sans/400.css";
import "@fontsource/ibm-plex-sans/500.css";
import "@fontsource/ibm-plex-mono/400.css";
import NeuralProjects from "./NeuralProjects.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <NeuralProjects />
  </StrictMode>
);

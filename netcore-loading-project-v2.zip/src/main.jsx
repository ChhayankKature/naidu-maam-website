import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import LoadingScreen from "./App.jsx";
import loader from "./loader.js";
import { startSampleLoad } from "./sampleData.js";
import "./App.css";

// Demo only: pretend three pieces of data take a while to arrive.
// Replace these with your real requests, e.g. loader.track(fetch("/api/..."))
// SAMPLE DATA: remove when real data is connected (see sampleData.js)
startSampleLoad(loader);

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <LoadingScreen fadeOut={false} />
  </StrictMode>
);
